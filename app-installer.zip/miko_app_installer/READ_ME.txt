api for getting anaylactis data-
http://localhost:8082/api/analytics?app_id=1&device_id=device_1

collection attached for connecting to websocket along with updated feature as well as sql table scripts attached

url- ws://localhost:8080/ws?deviceId=device_2

mesage- {
    "action": "UPDATE_STATUS",
    "deviceId": "device_2",
    "appId": 1,
    "version":1.0,
    "status": "SCHEDULED",
    "err_details":""
}

for getting the latest apps - ws://localhost:8080/ws?deviceId=device_2  
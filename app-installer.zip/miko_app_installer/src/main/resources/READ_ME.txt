api for getting anaylactis data-
http://localhost:8082/api/analytics?app_id=1&device_id=device_1

collection attached for connecting to websocket along with updated feature as well as sql table scripts attached
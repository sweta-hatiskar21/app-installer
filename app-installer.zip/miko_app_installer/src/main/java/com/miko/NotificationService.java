package com.miko;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.mail.SimpleEmail;

import io.vertx.core.Promise;
import io.vertx.core.Vertx;

public class NotificationService {

    private final Vertx vertx;

    public NotificationService(Vertx vertx) {
        this.vertx = vertx;
    }
    public void sendErrorNotification(String deviceId, int appId, String error_details) {
    	 vertx.executeBlocking((Promise<Void> promise) -> {
        try {
            Email email = new SimpleEmail();
            
            email.setHostName("smtp.gmail.com"); 
            email.setSmtpPort(465); 
            email.setSSLOnConnect(true); 
            email.setStartTLSEnabled(true); 
            email.setAuthenticator(new DefaultAuthenticator("example@gmail.com", "123456"));
            email.setFrom("example@gmail.com"); 
            email.addTo("example@gmail.com"); 
            email.setSubject("App Installation Failed for Device: " + deviceId);
            email.setMsg("App " + appId + " failed to install after 3 retries on device " + deviceId + " due to " + error_details);
            email.send();
            promise.complete();
        } catch (EmailException e) {
            e.printStackTrace();
            LoggerUtil.logInfo("error is-"+e);
            promise.fail(e);
        }
    	 }, res -> {
             if (res.succeeded()) {
                 LoggerUtil.logInfo("Email sent successfully for Device ID: " + deviceId);
             } else {
                 LoggerUtil.logError("Failed to send email notification", res.cause());
             }
         });
    }
}

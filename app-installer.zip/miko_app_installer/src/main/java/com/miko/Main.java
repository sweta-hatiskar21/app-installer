package com.miko;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.mysqlclient.MySQLConnectOptions;
import io.vertx.mysqlclient.MySQLPool;
import io.vertx.sqlclient.PoolOptions;
import io.vertx.sqlclient.SqlClient;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;

public class Main {

    private static final Logger logger = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        Vertx vertx = Vertx.vertx();

        Properties properties = new Properties();
        try (FileInputStream input = new FileInputStream("src/main/resources/application.properties")) {
            properties.load(input);
        } catch (IOException e) {
            logger.error("Error loading properties file: " + e.getMessage());
            return;
        }
        String host = properties.getProperty("db.host");
        int port = Integer.parseInt(properties.getProperty("db.port"));
        String dbName = properties.getProperty("db.name");
        String user = properties.getProperty("db.user");
        String password = properties.getProperty("db.password");

        // Create the MySQL connection options using the properties
        MySQLConnectOptions connectOptions = new MySQLConnectOptions()
                .setHost(host)
                .setPort(port)
                .setDatabase(dbName)
                .setUser(user)
                .setPassword(password); 

        PoolOptions poolOptions = new PoolOptions().setMaxSize(10);
        MySQLPool sqlClient = MySQLPool.pool(vertx, connectOptions, poolOptions);

        AppRepository appRepository = new AppRepository(sqlClient);
        NotificationService notificationService = new NotificationService(vertx);
        AppInstallService appInstallService = new AppInstallService(vertx, appRepository, notificationService);
         WebSocketServer webSocketServer = new WebSocketServer(vertx, appRepository,notificationService);
        webSocketServer.startServer();
        vertx.deployVerticle(new AppAnalyticsApi(appRepository), deployResult -> {
            if (deployResult.succeeded()) {
                System.out.println("AppAnalyticsApi verticle deployed successfully!");
            } else {
                System.err.println("Failed to deploy AppAnalyticsApi verticle: " + deployResult.cause());
            }
        });
       
    }
}

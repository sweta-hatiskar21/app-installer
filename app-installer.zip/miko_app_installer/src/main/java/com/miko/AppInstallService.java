package com.miko;

import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.json.JsonObject;

import java.util.Map;

public class AppInstallService {

    private final AppRepository appRepository;
    private final NotificationService notificationService;
    private final Vertx vertx;
    private final EventBus eventBus;

    public AppInstallService(Vertx vertx, AppRepository appRepository, NotificationService notificationService) {
        this.vertx = vertx;
        this.appRepository = appRepository;
        this.notificationService = notificationService;
        this.eventBus = vertx.eventBus();

       // eventBus.consumer("app.installation.status", message -> handleStatusUpdate(message.body().toString()));
        
       // vertx.setPeriodic(30000, id -> startInstallationProcess());
    }

//    public void startInstallationProcess() {
//        // Move blocking code to a worker thread
//        vertx.executeBlocking(promise -> {
//            appRepository.getAllDeviceIds().onSuccess(deviceIds -> {
//                for (String deviceId : deviceIds) {
//                    appRepository.getScheduledApps(deviceId).onSuccess(apps -> {
//                    	if (apps.isEmpty()) {
//                            LoggerUtil.logInfo("No scheduled apps for Device: " + deviceId);
//                            // After processing 'SCHEDULED', check 'ERROR' state apps
//                            rescheduleErrorApps(deviceId);
//                        } else {
//                        for (Map<String, Object> app : apps) {
//                            int appId = (int) app.get("id");
//                            String version = (String) app.get("version");
//                            JsonObject message = new JsonObject()
//                                    .put("appId", appId)
//                                    .put("deviceId", deviceId)
//                                    .put("status", "SCHEDULED")
//                                    .put("version", version);
//
//                            // Send message to the client via WebSocket
//                            sendMessageToClient(deviceId, message);
//
//                            LoggerUtil.logInfo("App " + appId + " scheduled for Device " + deviceId);
//                           // installApp(deviceId, appId); // Schedule the installation
//                        }}
//                    }).onFailure(err -> LoggerUtil.logError("Failed to fetch scheduled apps for device " + deviceId, err));
//                }
//                promise.complete(); // Signal completion
//            }).onFailure(err -> {
//                LoggerUtil.logError("Failed to fetch device IDs", err);
//                promise.fail(err);
//            });
//        }, res -> {
//            if (res.failed()) {
//                LoggerUtil.logError("Installation process failed", res.cause());
//            }
//        });
//    }



//    private void sendMessageToClient(String deviceId, JsonObject message) {
//        vertx.eventBus().publish("device." + deviceId, message); // Publish message to client via event bus
//        LoggerUtil.logInfo("Message sent to Device " + deviceId + ": " + message.encode());
//    }
//    
//    private void rescheduleErrorApps(String deviceId) {
//        appRepository.getErrorApps(deviceId).onSuccess(apps -> {
//            for (Map<String, Object> app : apps) {
//                int appId = (int) app.get("id");
//                String version = (String) app.get("version");
//                String error_details = (String) app.get("error_details");
//
//                // Update status to 'SCHEDULED' and reset retry attempts
//                appRepository.updateAppStatus(deviceId, appId, "SCHEDULED", null).onSuccess(v -> {
//                    appRepository.resetRetryAttempts(deviceId, appId).onSuccess(retries -> {
//                    	if (retries<3) {
//                        LoggerUtil.logInfo("Rescheduled app ID " + appId + " for Device " + deviceId);
//                        JsonObject message = new JsonObject()
//                                .put("appId", appId)
//                                .put("deviceId", deviceId)
//                                .put("status", "SCHEDULED")
//                                .put("version", version);
//
//                        sendMessageToClient(deviceId, message);
//                    	}else {
//                    		LoggerUtil.logInfo("Max retry attempts reached for Device " + deviceId + " and App " + appId);
//               
//                    		      notificationService.sendErrorNotification(deviceId,appId,error_details);
//						}
//                    	
//                    }).onFailure(err -> LoggerUtil.logError("Failed to reset retry attempts for App " + appId, err));
//                }).onFailure(err -> LoggerUtil.logError("Failed to update status for App " + appId, err));
//            }
//        }).onFailure(err -> LoggerUtil.logError("Failed to fetch ERROR state apps for Device: " + deviceId, err));
//    }


}

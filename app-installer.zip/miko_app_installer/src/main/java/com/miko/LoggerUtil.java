package com.miko;

import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LoggerUtil {

    private static final Logger logger = LoggerFactory.getLogger(LoggerUtil.class);
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static void logInfo(String message) {
        logger.info("[" + sdf.format(new Date()) + "] " + message);
    }

    public static void logError(String message, Throwable t) {
        logger.error("[" + sdf.format(new Date()) + "] " + message, t);
    }
}

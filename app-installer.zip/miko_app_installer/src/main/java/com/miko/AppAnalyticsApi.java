package com.miko;

import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

public class AppAnalyticsApi extends AbstractVerticle {

    private final AppRepository appRepository;

    public AppAnalyticsApi( AppRepository appRepository) {
        this.appRepository = appRepository;
    }

    
    @Override
    public void start(Promise<Void> startPromise) throws Exception {
     
        Router router = Router.router(vertx);
        router.route().handler(BodyHandler.create());
        router.get("/api/analytics").handler(this::getAnalytics);

        vertx.createHttpServer()
                .requestHandler(router)
                .listen(8082, http -> {
                    if (http.succeeded()) {
                        startPromise.complete();  
                        System.out.println("HTTP Server started on port 8082");
                    } else {
                        startPromise.fail(http.cause());  
                    }
                });
    }
    
    private void getAnalytics(RoutingContext routingContext) {
    	System.out.println("its not right");
        String appIdStr = routingContext.request().getParam("app_id");
        String deviceId = routingContext.request().getParam("device_id");

        if (appIdStr == null || deviceId == null) {
            routingContext.response()
                    .setStatusCode(400)
                    .end("app_id and device_id are required.");
            return;
        }

        try {
            int appId = Integer.parseInt(appIdStr);

            appRepository.getAppAnalytics(appId, deviceId)
                    .onSuccess(analytics -> {
                    	ObjectMapper objectMapper = new ObjectMapper();
                        objectMapper.registerModule(new JavaTimeModule());  // This will handle LocalDateTime serialization

                        JsonArray jsonArray = new JsonArray();
                        for (Map<String, Object> record : analytics) {
                            JsonObject jsonObject = new JsonObject(record);
                            String jsonString = null;
							try {
								jsonString = objectMapper.writeValueAsString(record);
							} catch (JsonProcessingException e) {
								e.printStackTrace();
							}
                            JsonObject jacksonJsonObject = new JsonObject(jsonString);
                            jsonArray.add(jacksonJsonObject);
                        }

                        routingContext.response()
                                .putHeader("Content-Type", "application/json")
                                .end(jsonArray.encode());
                    })
                    .onFailure(cause -> {
                        routingContext.response()
                                .setStatusCode(500)
                                .end("Error fetching analytics data: " + cause.getMessage());
                    });

        } catch (NumberFormatException e) {
            routingContext.response()
                    .setStatusCode(400)
                    .end("Invalid app_id format.");
        }
    }

}

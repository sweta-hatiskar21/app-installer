package com.miko;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.ServerWebSocket;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;

public class WebSocketServer {

    private final Vertx vertx;
    private final AppRepository appRepository;
    private static final Logger logger = LoggerFactory.getLogger(WebSocketServer.class);
    private final Map<String, Set<ServerWebSocket>> deviceConnections = new ConcurrentHashMap<>();
    private final NotificationService notificationService;

    
    public WebSocketServer(Vertx vertx, AppRepository appRepository, NotificationService notificationService) {
        this.vertx = vertx;
        this.appRepository = appRepository;
        this.notificationService = notificationService;
    }


    
    public void startServer() {
        vertx.createHttpServer().webSocketHandler(this::handleWebSocket).listen(8080, res -> {
            if (res.succeeded()) {
                logger.info("WebSocket server started on port 8080");
                startPollingForUpdates();
            } else {
                logger.error("Failed to start WebSocket server", res.cause());
            }
        });
    }

    private void handleWebSocket(ServerWebSocket webSocket) {

        // Get deviceId from query parameter  e.g. /ws?deviceId=123
        String deviceId = webSocket.query().split("=")[1];
        if (deviceId == null || deviceId.isEmpty()) {
            webSocket.reject(); // Reject connection if deviceId is missing
            return;
        }

        // Add connection to deviceConnections map
        deviceConnections.computeIfAbsent(deviceId, k -> ConcurrentHashMap.newKeySet()).add(webSocket);

        // Handle incoming messages
        webSocket.frameHandler(frame -> {
            JsonObject message = new JsonObject(frame.textData());
            String action = message.getString("action");
            if (action!=null && action.equalsIgnoreCase("UPDATE_STATUS")) {
            	handleUpdateStatus(webSocket, message);
			}
            else {
            	checkForNewAppsAndBroadcast();
			}
        });
        // Remove client on disconnect
        webSocket.closeHandler(close -> {
            deviceConnections.get(deviceId).remove(webSocket);
            logger.info("WebSocket closed for device: " + deviceId);
        });
        webSocket.exceptionHandler(err -> {
            logger.error("WebSocket error for device: " + deviceId, err);
        });
    }


    private void handleUpdateStatus(ServerWebSocket webSocket, JsonObject message) {
        String deviceId = message.getString("deviceId");
        int appId = message.getInteger("appId", -1);
        String status = message.getString("status");
        String version = message.getString("version");
        String err_details = message.getString("err_details");


        if (deviceId == null || appId <= 0 || status == null) {
            logger.error("Invalid message format: " + message.encode());
            webSocket.writeTextMessage(new JsonObject()
                    .put("error", "Invalid message format").encode());
            return;
        }

        if ("SCHEDULED".equals(status)) {
            appRepository.insertAppInstallation(deviceId, appId, status,version).onSuccess(v -> {
                logger.info("Inserted status SCHEDULED for App " + appId + " on Device " + deviceId);

                // Log analytics
                appRepository.logAnalytics(deviceId, appId, status, null);
                webSocket.writeTextMessage(new JsonObject()
                        .put("success", "Status SCHEDULED logged successfully").encode());
            }).onFailure(err -> {
                logger.error("Failed to insert status SCHEDULED", err);
                webSocket.writeTextMessage(new JsonObject()
                        .put("error", "Failed to insert status").encode());
            });
        } else {
            // Update the existing status
            appRepository.updateAppStatus(deviceId, appId, status,err_details).onSuccess(retries -> {
                appRepository.logAnalytics(deviceId, appId, status, null);
            	if (retries<3) {
            
                logger.info("Updated status to " + status + " for App " + appId + " on Device " + deviceId);

                // Log analytics
                webSocket.writeTextMessage(new JsonObject()
                        .put("success", "Status updated successfully").encode());
            	}else {
            		LoggerUtil.logInfo("Max retry attempts reached for Device " + deviceId + " and App " + appId);
       
            		      notificationService.sendErrorNotification(deviceId,appId,err_details);
            		      webSocket.writeTextMessage(new JsonObject()
                                  .put("success", "Mail sent successfully for logging error").encode());
                      	
				}
            }).onFailure(err -> {
                logger.error("Failed to update status", err);
                webSocket.writeTextMessage(new JsonObject()
                        .put("error", "Failed to update status").encode());
            });
        }
    }

    
    private void broadcastAppUpdate(String deviceId, JsonObject appUpdateMessage) {
        Set<ServerWebSocket> clients = deviceConnections.get(deviceId);
        if (clients != null && !clients.isEmpty()) {
            for (ServerWebSocket client : clients) {
                client.writeTextMessage(appUpdateMessage.encode());
            }
        }
    }
    
    private void startPollingForUpdates() {
        vertx.setPeriodic(60000, id -> {  // Poll every 60 seconds (adjust as necessary)
            checkForNewAppsAndBroadcast();
        });
    }
    private void checkForNewAppsAndBroadcast() {
        // Iterate over all connected devices
        for (String deviceId : deviceConnections.keySet()) {
            // Fetch scheduled apps for each deviceId
            appRepository.getScheduledApps(deviceId).onSuccess(apps -> {
                if (apps.isEmpty()) {
                    logger.info("No scheduled apps for Device: " + deviceId);
                    // After processing 'SCHEDULED', check 'ERROR' state apps
                    rescheduleErrorApps(deviceId);
                } else {
                    JsonArray appList = new JsonArray();

                    // Collect apps for the given deviceId
                    for (Map<String, Object> app : apps) {
                        appList.add(new JsonObject()
                                .put("appId", app.get("id"))
                                .put("name", app.get("app_name"))
                                .put("version", app.get("version"))
                                .put("status", "SCHEDULED"));
                    }

                    // Prepare the response to send to the device
                    JsonObject response = new JsonObject()
                            .put("deviceId", deviceId)
                            .put("apps", appList);

                    // Broadcast the update to all clients
                    broadcastAppUpdate(deviceId,response);
                }
            }).onFailure(err -> {
                logger.error("Failed to fetch apps for device: " + deviceId, err);
            });
        }
    }

    
    private void rescheduleErrorApps(String deviceId) {
        appRepository.getErrorApps(deviceId).onSuccess(apps -> {
            for (Map<String, Object> app : apps) {
                int appId = (int) app.get("id");
                String version = (String) app.get("version");
                appRepository.updateRescheduledStatus(deviceId, appId, "SCHEDULED").onSuccess(v -> {
                       JsonObject message = new JsonObject()
                                .put("appId", appId)
                                .put("deviceId", deviceId)
                                .put("status", "SCHEDULED")
                                .put("version", version);

                        broadcastAppUpdate(deviceId, message);
                });
            }
                }).onFailure(err -> LoggerUtil.logError("Failed to update status for App ", err));
            }
  

}


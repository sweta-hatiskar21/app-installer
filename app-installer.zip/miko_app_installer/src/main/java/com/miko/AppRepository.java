package com.miko;

import io.vertx.core.Future;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;
import io.vertx.sqlclient.SqlClient;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.Tuple;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppRepository {

    private final SqlClient sqlClient; 
    private static final Logger logger = LoggerFactory.getLogger(Main.class);

    public AppRepository(SqlClient sqlClient) {
        this.sqlClient = sqlClient;
    }

   
    

    public Future<List<Map<String, Object>>> getScheduledApps(String deviceId) {
        String query = "SELECT a.id, a.app_name, a.version FROM app_data a LEFT JOIN app_installation i ON a.id = i.app_id AND i.device_id = ? WHERE a.status = 'SCHEDULED' AND (i.id IS NULL OR i.version < a.version )";
        return sqlClient.preparedQuery(query).execute(Tuple.of(deviceId))
            .map(res -> {
                List<Map<String, Object>> appList = new ArrayList<>();

                for (Row row : res) {
                    Map<String, Object> app = new HashMap<>();

                    for (int i = 0; i < row.size(); i++) {
                        String column = row.getColumnName(i); 
                        Object value = row.getValue(i);      
                        app.put(column, value);             
                    }

                    appList.add(app); 
                }

                return appList; 
            });
    }


    public Future<Void> logAnalytics(String deviceId, int appId, String status, String errorDetails) {
    	logger.info("there ---------------------------");
        String query = "INSERT INTO app_analytics (app_id, device_id, status, timestamp, error_message) VALUES (?, ?, ?, NOW(), ?)";
        return sqlClient.preparedQuery(query).execute(Tuple.of(appId, deviceId, status, errorDetails))
                .mapEmpty();
    }

    public Future<Void> insertAppInstallation(String deviceId, int appId, String status,String version) {
        String query = "INSERT INTO app_installation (device_id, app_id, status, created_date,version) VALUES (?, ?, ?, NOW(),?)";
        return sqlClient.preparedQuery(query)
                .execute(Tuple.of(deviceId, appId, status,version))
                .mapEmpty();
    }

    public Future<Integer> updateAppStatus(String deviceId, int appId, String status, String err_details) {
        String query = "UPDATE app_installation SET status = ?,error_details=?, attempts = attempts + 1, last_updated = NOW() WHERE device_id = ? AND app_id = ?";
        return sqlClient.preparedQuery(query)
                .execute(Tuple.of(status,err_details, deviceId, appId))
                .compose(updateResult -> {
                    // After update, retrieve the updated attempts count
                    String selectQuery = "SELECT attempts FROM app_installation WHERE device_id = ? AND app_id = ?";
                    return sqlClient.preparedQuery(selectQuery)
                        .execute(Tuple.of(deviceId, appId))
                        .map(rowSet -> {
                            // Assuming there is only one row returned
                            return rowSet.iterator().hasNext() ? rowSet.iterator().next().getInteger("attempts") : 0;
                        });
                });
    }
    
    public Future<List<Map<String, Object>>> getErrorApps(String deviceId) {
        String query = "SELECT app_id, version,error_details FROM app_installation WHERE device_id = ? AND status = 'ERROR' and attempts<>3";
        return sqlClient.preparedQuery(query).execute(Tuple.of(deviceId)).map(rowSet -> {//preparedQuery(query).execute(Tup
            List<Map<String, Object>> apps = new ArrayList<>();
            rowSet.forEach(row -> {
                Map<String, Object> app = new HashMap<>();
                app.put("id", row.getInteger("app_id"));
                app.put("version", row.getString("version"));
                app.put("error_details", row.getString("error_details"));
                apps.add(app);
            });
            return apps;
        });
    }


    public Future<List<Map<String, Object>>> getNewScheduledApps() {
        String query = "SELECT a.id, a.app_name, a.version " +
                       "FROM app_data a " +
                       "LEFT JOIN app_installation i ON a.id = i.app_id " +
                       "WHERE a.status = 'SCHEDULED' " +
                       "AND (i.id IS NULL OR i.version < a.version)";

        return sqlClient.preparedQuery(query).execute()
            .map(res -> {
                List<Map<String, Object>> appList = new ArrayList<>();

                for (Row row : res) {
                    Map<String, Object> app = new HashMap<>();

                    for (int i = 0; i < row.size(); i++) {
                        String column = row.getColumnName(i); 
                        Object value = row.getValue(i);       
                        app.put(column, value);               
                    }

                    appList.add(app); 
                }

                return appList; 
            });
    }

    public Future<Void> updateRescheduledStatus(String deviceId, int appId, String status) {
        String query = "UPDATE app_installation SET status = ?, last_attempted = NOW() WHERE device_id = ? AND app_id = ?";
        return sqlClient.preparedQuery(query)
                .execute(Tuple.of(status, deviceId, appId))
                .mapEmpty();
    }
    
    public Future<List<Map<String, Object>>> getAppAnalytics(int appId, String deviceId) {
        String query = "SELECT id, app_id, device_id, status, error_message, timestamp FROM app_analytics WHERE app_id = ? AND device_id = ?";
        Tuple params = Tuple.of(appId, deviceId);

        return sqlClient.preparedQuery(query).execute(params)
                .map(res -> {
                    List<Map<String, Object>> appList = new ArrayList<>();

                    for (Row row : res) {
                        Map<String, Object> app = new HashMap<>();

                        for (int i = 0; i < row.size(); i++) {
                            String column = row.getColumnName(i); 
                            Object value = row.getValue(i);      
                            app.put(column, value);             
                        }

                        appList.add(app); 
                    }

                    return appList; 
                });
    }
}
